# Yate-YateBTS
This version of Yate and YateBTS works perfectly with BladeRFx40 Firmware: 1.9.1 and FPGA: 0.1.2

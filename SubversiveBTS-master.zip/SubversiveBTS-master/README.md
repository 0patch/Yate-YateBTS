# SubversiveBTS

This repository contains specific patched versions of Yate and YateBTS that are working with the Nuand bladeRF x40.

Special thanks to Simone Margaritelli of EvilSocket (https://www.evilsocket.net) for having done all the work on these specific patched versions.

